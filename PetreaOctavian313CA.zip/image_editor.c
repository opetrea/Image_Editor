#include <stdio.h>
#include <stdlib.h>
#include "image_functions.h"

int main(void)
{
	int **img, n = 0, m = 0, limita = 0, x1 = 0, x2 = 0, y1 = 0, y2 = 0,
		loaded = 0, command = 0;
	char s[2000], *type = malloc(3 * sizeof(char)),
		 **word = alloc_matrix_char(10, 50);
	while (1) {
		command = 0;
		/*Citesc cate un rand de la tastatura, ca mai apoi sa-l
		impart in cuvinte*/
		fgets(s, 2000, stdin);
		word_to_word(&word, s);
		if (strcmp(word[0], "LOAD") == 0) {
			if (loaded == 1) {
				free_matrix(&img, n);
				loaded = 0;
			}
			img = load_f(word, &n, &m, &limita, &type, &loaded);
			x1 = 0, x2 = m, y1 = 0, y2 = n;
			command = 1;
		}
		if (strcmp(word[0], "SELECT") == 0) {
			select_function(word, &x1, &y1, &x2, &y2, n, m, loaded);
			command = 1;
		}
		if (strcmp(word[0], "HISTOGRAM") == 0) {
			histogram_function(word, n, m, img, type, loaded);
			command = 1;
		}
		if (strcmp(word[0], "CROP") == 0) {
			crop_function(&n, &m, &img, x1, y1, x2, y2, type, loaded);
			command = 1;
			x1 = 0;
			y1 = 0;
			x2 = m;
			y2 = n;
		}
		if (strcmp(word[0], "EQUALIZE") == 0) {
			equalize_function(n, m, &img, loaded, type);
			command = 1;
		}
		if (strcmp(word[0], "APPLY") == 0) {
			apply_function(word, n, m, &img, x1, x2, y1, y2, type, loaded);
			command = 1;
		}
		if (strcmp(word[0], "SAVE") == 0) {
			save_function(word, n, m, img, type, limita, loaded);
			command = 1;
		}
		if (strcmp(word[0], "ROTATE") == 0) {
			rotate_func(word, &n, &m, &img, &x1, &x2, &y1, &y2, type, loaded);
			command = 1;
		}
		if (strcmp(word[0], "EXIT") == 0) {
			if (loaded == 0)
				printf("No image loaded\n");
			/*Opresc citirea comenzilor la introducerea comenzii EXIT*/
			break;
		}
		/*Verific daca comanda introdusa de la tastatura este una valida*/
		if (command == 0)
			printf("Invalid command\n");
	}
	/*Dealoc memorie alocata*/
	free_matrix_char(&word, 10);
	free(type);
	if (loaded == 1)
		free_matrix(&img, n);
	return 0;
}
